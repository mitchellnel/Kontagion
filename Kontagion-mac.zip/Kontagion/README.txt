To run Kontagion:

1. Locate the folder Kontagion, which should have in it files named
Kontagion and Assets.  It's likely that the path to the folder will be
/Users/yourname/Kontagion or /Users/yourname/Downloads/Kontagion.

2. Open a Terminal window and type
        cd whateverThePathIs
where you should replace whateverThePathIs with the path to the Kontagion
folder.

3. Confirm you're in the right folder by typing
        ls
which should show you the Assets folder and the Kontagion executable.

4. Type
        ./Kontagion
to play the game.

Alternatively, in the folder Kontagion, you can move the Assets folder
to your home directory, then double-click on the Kontagion executable
file.
